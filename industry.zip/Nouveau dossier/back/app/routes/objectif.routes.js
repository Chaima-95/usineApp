/** @format */
module.exports = (app) => {
  const objectif = require("../controllers/objectif.controller.js");
  var route = require("express").Router();

  route.post("/create", objectif.create);
  route.get("/getall", objectif.getall);
  route.get("/getbyid/:id", objectif.getbyid);
  route.get("/getbyname", objectif.getbyname);
  route.put("/update/:id", objectif.update);
  route.delete("/delete/:id", objectif.delete);
  app.use("/api/objectif", route);
};
