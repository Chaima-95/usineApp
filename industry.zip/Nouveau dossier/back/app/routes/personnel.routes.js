/** @format */
module.exports = (app) => {
  const personnel = require("../controllers/personnel.controller.js");
  var route = require("express").Router();

  route.post("/create", personnel.create);
  route.get("/getall", personnel.getall);
  route.get("/getbyid/:id", personnel.getbyid);
  route.get("/getbyname", personnel.getbyname);
  route.put("/update/:id", personnel.update);
  route.delete("/delete/:id", personnel.delete);
  app.use("/api/personnel", route);
};
