/** @format */
module.exports = (app) => {
  const line = require("../controllers/line.controller.js");
  var route = require("express").Router();

  route.post("/create", line.create);
  route.get("/getall", line.getall);
  route.get("/getbyid/:id", line.getbyid);
  route.get("/getbyname", line.getbyname);
  route.put("/update/:id", line.update);
  route.delete("/delete/:id", line.delete);
  app.use("/api/line", route);
};
