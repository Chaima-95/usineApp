/** @format */

const mongoose = require("mongoose");
const Alea = mongoose.model(
  "Alea",
  new mongoose.Schema(
    {
      name: {
        type: String,
        required: true,
        trim: true,
      },
      product: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Product",
        },
      ],
    },
    { timestamps: true }
  )
);

module.exports = Alea;
