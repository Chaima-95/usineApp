/** @format */

const mongoose = require("mongoose");
const Planification = mongoose.model(
  "Planification",
  new mongoose.Schema(
    {
      zone: {
        type: mongoose.Schema.Types.Object,
        ref: "Zone",
      },
      lines: [
        {
          type: mongoose.Schema.Types.Object,
          ref: "Line",
        },
      ],
      objectifInHour: {
        type: Number,
        trim: true,
      },
      objectifInWeek: {
        type: Number,
        trim: true,
      },
    },
    { timestamps: true }
  )
);

module.exports = Planification;
