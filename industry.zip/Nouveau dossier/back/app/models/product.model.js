/** @format */

const mongoose = require("mongoose");
const Product = mongoose.model(
  "Product",
  new mongoose.Schema(
    {
      code: {
        type: String,
        required: true,
        trim: true,
      },
      name: {
        type: String,
        required: true,
        trim: true,
      },
      phase: {
        type: String,
        required: true,
        trim: true,
      },
      productionInHour: {
        type: Number,
        required: true,
        trim: true,
      },
    },
    { timestamps: true }
  )
);

module.exports = Product;
