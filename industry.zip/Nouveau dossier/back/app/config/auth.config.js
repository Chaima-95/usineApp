/** @format */

module.exports = {
  secret: "usine-secret-key",
};
