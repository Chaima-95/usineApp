/** @format */

module.exports = {
  HOST: "localhost",
  PORT: 27017,
  DB: "usine_db",
};
