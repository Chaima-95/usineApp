/** @format */

const objectifModel = require("../models/objectif.model");
module.exports = {
  create: async (req, res) => {
    const objectif = new objectifModel(req.body);
    await objectif.save(req.body, (err, objectif) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created objectif",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "objectif Added successufly",
          data: objectif,
        });
      }
    });
  },
  getall: async (req, res) => {
    await objectifModel.find({}).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all objectifs" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of objectifs",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await objectifModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res.status(406).json({ success: false, message: "Failed to get objectif" });
      } else {
        res.status(201).json({ success: true, message: "objectif", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await objectifModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  objectif by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of objectifs",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await objectifModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update objectif" });
        } else {
          res.status(201).json({
            success: true,
            message: "objectif updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await objectifModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to deleted objectif" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "objectif deleted successfuly" });
      }
    });
  },
};
