/** @format */

exports.allAccess = (req, res) => {
  res.status(200).send("Public Interface.");
};

exports.userBoard = (req, res) => {
  res.status(200).send("User Interface.");
};

exports.adminBoard = (req, res) => {
  res.status(200).send("Admin Interface.");
};

exports.superadminBoard = (req, res) => {
  res.status(200).send("Superadmin Interface.");
};
