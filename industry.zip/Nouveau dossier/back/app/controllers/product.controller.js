/** @format */

const productModel = require("../models/product.model");
module.exports = {
  create: async (req, res) => {
    const product = new productModel(req.body);
    console.log(req.body);
    await product.save(req.body, (err, product) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created product",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "product Added successufly",
          data: product,
        });
      }
    });
  },
  getall: async (req, res) => {
    await productModel.find({}).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all products" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of products",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await productModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get product" });
      } else {
        res.status(201).json({ success: true, message: "product", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await productModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  product by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of products",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await productModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update product" });
        } else {
          res.status(201).json({
            success: true,
            message: "product updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await productModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to deleted product" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "product deleted successfuly" });
      }
    });
  },
};
