/** @format */

const lineModel = require("../models/line.model");
module.exports = {
  create: async (req, res) => {
    const line = new lineModel(req.body);
    await line.save(req.body, (err, line) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to created line",
          data: null,
        });
        console.log(err);
      } else {
        res.status(201).json({
          success: true,
          message: "line Added successufly",
          data: line,
        });
      }
    });
  },
  getall: async (req, res) => {
    let query = {};
    if (req.query.searchQuery) {
      query.name = {
        $regex: new RegExp("^" + req.query.searchQuery.trim() + ".*", "i"),
      };
    }
    await lineModel.find(query).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to get all lines" });
      } else {
        res.status(201).json({
          success: true,
          message: "List of lines",
          data: items,
        });
      }
    });
  },
  getbyid: async (req, res) => {
    await lineModel.findById(req.params.id).exec((err, item) => {
      if (err) {
        res.status(406).json({ success: false, message: "Failed to get line" });
      } else {
        res.status(201).json({ success: true, message: "line", data: item });
      }
    });
  },
  getbyname: async (req, res) => {
    await lineModel.find({ name: req.query.name }).exec((err, items) => {
      if (err) {
        res.status(406).json({
          success: false,
          message: "Failed to get  line by this name",
        });
      } else {
        res.status(201).json({
          success: true,
          message: "List of lines",
          data: items,
        });
      }
    });
  },
  update: async (req, res) => {
    await lineModel
      .findByIdAndUpdate(req.params.id, req.body, { new: true })
      .exec((err, item) => {
        if (err) {
          res
            .status(406)
            .json({ success: false, message: "Failed to update line" });
        } else {
          res.status(201).json({
            success: true,
            message: "line updated successfuly",
            data: item,
          });
        }
      });
  },
  delete: async (req, res) => {
    await lineModel.findByIdAndRemove(req.params.id).exec((err, items) => {
      if (err) {
        res
          .status(406)
          .json({ success: false, message: "Failed to deleted line" });
      } else {
        res
          .status(201)
          .json({ success: true, message: "line deleted successfuly" });
      }
    });
  },
};
