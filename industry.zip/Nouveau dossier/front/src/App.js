/** @format */

import React, { useState, useEffect, useCallback } from "react";
import { Router, Switch, Route } from "react-router-dom";

import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import Login from "./pages/login/Login";
import Register from "./pages/registration/Register";
import Home from "./pages/Home";
import Profile from "./pages/profile/Profile";
import BoardUser from "./pages/BoardUser";
import BoardSuperadmin from "./pages/BoardSuperadmin";
import BoardAdmin from "./pages/BoardAdmin";
import ProdReport from "./pages/report_indus/ProdReport";
import List from "./pages/usersList/List";

// import AuthVerify from "./common/AuthVerify";
import Sidebar from "./components/sidebar/Sidebar";
import Navbar from "./components/navbar/Navbar";

import Range from "./pages/range/Range";
import Personnel from "./pages/personnel/Personnel";
import Uap from "./pages/uap's/Uap";
import authService from "./services/auth.service";

const App = () => {
  console.warn = () => {};

  const [currentUser, setCurrentUser] = useState(undefined);
  const [sidebarOpen, setsidebarOpen] = useState(false);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  }, []);

  const openSidebar = () => {
    setsidebarOpen(true);
  };
  const closeSidebar = () => {
    setsidebarOpen(false);
  };

  return (
    <>
      <div className='contenu'>
        <Switch>
          {!currentUser ? (
            <Route exact path={"/login"} component={Login} />
          ) : (
            <>
              <Navbar sidebarOpen={sidebarOpen} openSidebar={openSidebar} />
              <Sidebar sidebarOpen={sidebarOpen} closeSidebar={closeSidebar} />
              <Route exact path={["/", "/home"]} component={Home} />
              <Route exact path='/register' component={Register} />
              <Route exact path='/profile' component={Profile} />
              <Route path='/user' component={BoardUser} />
              <Route path='/superadmin' component={BoardSuperadmin} />
              <Route path='/admin' component={BoardAdmin} />
              <Route path='/range' component={Range} />
              <Route path='/personnel' component={Personnel} />
              <Route path='/report/production' component={ProdReport}></Route>
              <Route path='/uap' component={Uap} />
              <Route path='/usersList' component={List} />
            </>
          )}
        </Switch>
      </div>
    </>
  );
};

export default App;
