/** @format */

import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";

const ZapAddButton = () => {
  const [addLigne, setaddLigne] = useState([]);
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [show1, setShow1] = useState(false);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);
  const [show2, setShow2] = useState(false);
  const handleClose2 = () => {
    setShow2(false);
    setaddLigne([]);
  };
  const handleShow2 = () => setShow2(true);
  const [show3, setShow3] = useState(false);
  const handleClose3 = () => setShow3(false);
  const handleShow3 = () => setShow3(true);

  const [zones, setZones] = useState([]);
  const [name, setName] = useState("");
  const [responsableName, setResponsableName] = useState("");
  const [lines, setLines] = useState("[{}]");
  const [products, setProducts] = useState("{}");
  const handelLignes = () => {
    setaddLigne((array) => [
      ...array,
      <>
        <hr />
        <Form.Group className='mb-3'>
          <Form.Label style={{ fontWeight: "500" }}>Nom de la ligne</Form.Label>
          <Form.Control
            // onChange={(e) => setLineName(e.target.value)}
            type='text'
            placeholder='nom ligne'
          />
          <Form.Label style={{ fontWeight: "500" }}>Nom du produit</Form.Label>
          <Form.Control
            // onChange={(e) => setProductName(e.target.value)}
            type='text'
            placeholder='nom du produit'
          />
          <Form.Label style={{ fontWeight: "500" }}>Phase</Form.Label>
          <Form.Control
            // onChange={(e) => setPhase(e.target.value)}
            type='text'
            placeholder='phase'
          />
        </Form.Group>
      </>,
    ]);
  };
  return (
    <div>
      <Button
        style={{
          marginLeft: "10px",
          marginTop: "7px",
        }}
        onClick={handleShow2}
        variant='danger'>
        +zap
      </Button>
      <Modal show={show2} onHide={handleClose2}>
        <Modal.Header closeButton>
          <Modal.Title> Ajouter ZAP</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group>
            <Form.Label style={{ fontWeight: "500" }}>
              Nom du nouveau ZAP
            </Form.Label>
            <Form.Control
              autocomplete='on'
              onChange={(e) => setName(e.target.value)}
              type='text'
              placeholder='nom du ZAP'
            />
            <Form.Label style={{ fontWeight: "500" }}>
              Nom du responsable ZAP
            </Form.Label>
            <Form.Control
              onChange={(e) => setResponsableName(e.target.value)}
              type='text'
              placeholder='nom du responsable'
            />
          </Form.Group>

          <>
            <hr />
            <Form.Group className='mb-3'>
              <Form.Label style={{ fontWeight: "500" }}>
                Nom de la ligne
              </Form.Label>
              <Form.Control
                onChange={(e) => setLines(e.target.value)}
                type='text'
                placeholder='nom ligne'
              />
              <Form.Label style={{ fontWeight: "500" }}>
                Nom du produit
              </Form.Label>
              <Form.Control
                onChange={(e) => setProducts(e.target.value)}
                type='text'
                placeholder='nom du produit'
              />
              <Form.Label style={{ fontWeight: "500" }}>Phase</Form.Label>
              <Form.Control
                onChange={(e) => setLines(e.target.value)}
                type='text'
                placeholder='phase'
              />
            </Form.Group>
          </>

          <Button
            variant='btn btn-sm'
            style={{
              backgroundColor: "#E4E4E4",
              borderColor: "#161E54",
              textColor: "#161E54",
              fontWeight: "700",
            }}
            onClick={handelLignes}>
            + ligne
          </Button>
          {addLigne.map((item) => (
            <>{item}</>
          ))}
        </Modal.Body>
        <Modal.Footer>
          <Button variant='btn btn-primary btn-sm' onClick={handleClose2}>
            Ajouter ZAP
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ZapAddButton;
