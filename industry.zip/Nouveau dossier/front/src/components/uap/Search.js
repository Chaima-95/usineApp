/** @format */

import React, { useEffect, useState } from "react";
import lineService from "../../services/line.service";
import personnelService from "../../services/personnel.service";
import productService from "../../services/product.service";
import zoneService from "../../services/zone.service";

function Search({ searchWord, currentInput, addZapState, setAddZapState }) {
  const [filtredArray, setfiltredArray] = useState([]);
  useEffect(() => {
    switch (currentInput) {
      case "zoneName":
        zoneService
          .getFiltredZones(searchWord)
          .then((res) => setfiltredArray(res.data.data));
        break;
      case "lineName":
        lineService
          .getFiltredLines(searchWord)
          .then((res) => setfiltredArray(res.data.data));
        break;
      case "responsableName":
        personnelService
          .getFiltredPersonnels(searchWord)
          .then((res) => setfiltredArray(res.data.data));
        break;
      case "productName":
        productService
          .getFiltredProducts(searchWord)
          .then((res) => setfiltredArray(res.data.data));
        break;

      case "phaseName":
        break;
      default:
        break;
    }
  }, [searchWord]);

  return (
    <div
      style={{
        width: "100%",
        maxHeight: "100px",
        overflow: "auto",

        borderRadius: "5px",
        padding: "5px",
      }}>
      {filtredArray &&
        filtredArray.map((item, index) => (
          <div
            onClick={() => {
              setAddZapState({
                ...addZapState,
                name: item.name,
              });

              setfiltredArray([item]);
            }}
            style={{ cursor: "pointer" }}
            key={index}>
            {item.name}
            <hr />
          </div>
        ))}
    </div>
  );
}

export default Search;
