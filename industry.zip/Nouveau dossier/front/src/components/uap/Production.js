/** @format */

import React, { useState } from "react";
import { useEffect } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import planificationService from "../../services/planification.service";
import productService from "../../services/product.service";
import personnelService from "../../services/personnel.service";
import aleaService from "../../services/alea.service";

const Production = () => {
  // form validation rules
  const validationSchema = Yup.object().shape({
    numberOfPersons: Yup.string().required("Number of persons is required"),
    productName: Yup.string().required("Nom du produit is required"),
    hour: Yup.string().required("Heure de saisie is required"),

    date: Yup.string().required("Date is required"),

    piecesProduced: Yup.string().required(
      "Nombre des pièces produites is required"
    ),

    nonConform: Yup.string().required(
      "Nombre des pièces non conformes is required"
    ),
    alea: Yup.string().required("alea  is required"),
    comment: Yup.string().required("Comentaire is required"),

    persons: Yup.array().of(
      Yup.object().shape({
        matricule: Yup.string().required("Matricule is required"),
      })
    ),
  });

  const formOptions = { resolver: yupResolver(validationSchema) };
  // functions to build form returned by useForm() and useFieldArray() hooks
  const { register, control, handleSubmit, reset, formState, watch } =
    useForm(formOptions);
  const { errors } = formState;
  const { fields, append, remove } = useFieldArray({
    name: "persons",
    control,
  });
  // watch to enable re-render when ticket number is changed
  const numberOfPersons = watch("numberOfPersons");
  //*------GET ALL PRODUCTS */
  const [planification, setPlanification] = useState([]);
  const [personnels, setPersonnels] = useState([]);
  const [aleas, setAleas] = useState([]);
  const [products, setProducts] = useState([]);
  const getAllProducts = () => {
    planificationService
      .getAll()
      .then((res) => {
        console.log(res.data.data);
        setPlanification(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllPersonnels = () => {
    personnelService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setPersonnels(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllAleas = () => {
    aleaService
      .getAll()
      .then((res) => {
        //console.log(res.data.data);
        setAleas(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    // update field array when ticket number changed
    const newVal = parseInt(numberOfPersons || 0);
    const oldVal = fields.length;
    getAllProducts();
    getAllPersonnels();
    getAllAleas();
    if (newVal > oldVal) {
      // append tickets to field array
      for (let i = oldVal; i < newVal; i++) {
        append({ matricule: "" });
      }
    } else {
      // remove tickets from field array
      for (let i = oldVal; i > newVal; i--) {
        remove(i - 1);
      }
    }
  }, [numberOfPersons]);
  function onSubmit(data) {
    // display form data on success
    alert("SUCCESS!! :-)\n\n" + JSON.stringify(data, null, 4));
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className='card m-3'>
        <h5 className='card-header'>
          Veuillez entrer la production de l'heure 22h - 23h de mardi 17 mai
          2022
        </h5>
        <div className='card-body border-bottom'>
          <label>Nom du produit</label>
          <select className='form-control'>
            <option value=''></option>
            {planification.map((item, index) => {
              {
                item.lines.map((item, index) => {
                  return (
                    console.log(item.product.name),
                    (
                      <option
                        value={JSON.stringify(item.product.name)}
                        key={index}>
                        {item.product.name}
                      </option>
                    )
                  );
                });
              }
            })}
          </select>
          <label>Heure du saisie</label>
          <select className='form-control'>
            {[
              "",
              1,
              2,
              3,
              4,
              5,
              6,
              7,
              8,
              9,
              10,
              11,
              12,
              13,
              14,
              15,
              16,
              17,
              18,
              19,
              20,
              21,
              22,
              23,
            ].map((i) => (
              <option key={i} value={i}>
                {i}
              </option>
            ))}
          </select>
          <label>Date</label>
          <input className='form-control' type='date' />
          <label>Nombre des pièces produite</label>
          <input className='form-control' type='number' />
          <label>Nombre des personnes</label>
          {/** ------------  nbr of persons --------- */}
          <select
            {...register("numberOfPersons")}
            className={`form-control ${
              errors.numberOfPersons ? "is-invalid" : ""
            }`}>
            {["", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
              <option key={i} value={i}>
                {i}
              </option>
            ))}
          </select>
          <div className='invalid-feedback'>
            {errors.numberOfPersons?.message}
          </div>
          {fields.map((item, i) => (
            <div key={i} className='list-group list-group-flush'>
              <h5>Matricule {i + 1}</h5>
              <select
                name={`persons[${i}]matricule`}
                {...register(`persons.${i}.matricule`)}
                type='text'
                className={`form-control ${
                  errors.persons?.[i]?.matricule ? "is-invalid" : ""
                }`}>
                {personnels.map((item, index) => {
                  return (
                    <option value={JSON.stringify(item)} key={index}>
                      {item.matricule}
                    </option>
                  );
                })}
              </select>
              <div className='invalid-feedback'>
                {errors.persons?.[i]?.matricule?.message}
              </div>
            </div>
          ))}
          <label>Nombre des pièces non conformes</label>
          <input className='form-control' type='number' />
          <label>Alea</label>
          <select
            className={`form-control ${errors.alea ? "is-invalid" : ""}`}
            type='text'>
            <option value=''></option>
            {aleas.map((item, index) => {
              return (
                <option value={JSON.stringify(item)} key={index}>
                  {item.name}
                </option>
              );
            })}
          </select>

          <label>Commentaire</label>
          <textArea className='form-control' />
        </div>

        <div className='card-footer text-center border-top-0'>
          <button type='submit' className='btn btn-primary mr-1'>
            Enregistrer
          </button>
          <button
            onClick={() => reset()}
            type='button'
            className='btn btn-secondary mr-1'>
            Reset
          </button>
        </div>
      </div>
    </form>
  );
};

export default Production;
