/** @format */

import React, { useEffect, useRef, useState } from "react";
import "./personnel.css";
import personnelService from "../../services/personnel.service";
import zoneService from "../../services/zone.service";
import { useParams } from "react-router-dom";

const Personnel = (props) => {
  const [personnels, setPersonnels] = useState([]);
  const [zones, setZones] = useState([]);
  const [name, setName] = useState("");
  const [matricule, setMatricule] = useState("");
  const [zone, setZone] = useState("{}");
  // const { id } = useParams();

  const personnelsRef = useRef();
  personnelsRef.current = personnels;

  const addPersonnel = () => {
    personnelService
      .add({
        name,
        matricule,
        zone: { id: JSON.parse(zone)._id, name: JSON.parse(zone).name },
      })
      .then((res) => {
        console.log(res.data.data);
        console.log("success");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // ************ delete personnel *********** //
  const deletePersonnel = (rowIndex) => {
    const id = personnelsRef.current[rowIndex]._id;
    personnelService
      .remove(id)
      .then((response) => {
        let newPersonnels = [...personnelsRef.current];
        newPersonnels.splice(rowIndex, 1);
        setPersonnels(newPersonnels);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const getAllZones = () => {
    zoneService
      .getAll()
      .then((res) => {
        // console.log(res);
        setZones(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const getAllPersonnels = () => {
    personnelService
      .getAll()
      .then((res) => {
        // console.log(res.data.data);
        setPersonnels(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getAllZones();
    getAllPersonnels();
  }, []);
  return (
    <div className='container machines_container'>
      <div className='row machine_title'>
        <div className='col-md'>
          <h6>Personnel</h6>
        </div>
      </div>
      {/* INPUTS */}
      <form onSubmit={addPersonnel}>
        <div className='row'>
          <div className='col-md'>
            <label style={{ fontWeight: "500" }}>Matricule</label>
            <input
              onChange={(e) => setName(e.target.value)}
              className='form-control'
              style={{ height: "50%" }}
              type='text'
            />
          </div>
          <div className='col-md'>
            <label style={{ fontWeight: "500" }}>Name</label>
            <input
              onChange={(e) => setMatricule(e.target.value)}
              className='form-control'
              style={{ height: "50%" }}
              type='text'
            />
          </div>
          <div className='col-md'>
            <label style={{ fontWeight: "500" }}>Zone</label>
            <select
              className='form-control'
              onChange={(e) => setZone(e.target.value)}
              style={{ height: "50%" }}>
              <option value=''></option>
              {zones.map((item, index) => {
                return (
                  <option value={JSON.stringify(item)} key={index}>
                    {item.name}
                  </option>
                );
              })}
            </select>
          </div>
        </div>
        <div className='valid_button'>
          <button
            // onClick={() => addPersonnel()}
            className='btn btn-primary'
            style={{
              height: "37px",
              width: "10%",
            }}>
            Add
          </button>
        </div>
      </form>
      <hr style={{ width: "50%", marginLeft: "20%" }} />
      <br />

      {/* END */}
      <div>
        <div class='row'>
          <div class='col-md-12'>
            <div class='panel panel-default'>
              <div class='panel-body panel-body-table'>
                <div class='table-responsive'>
                  <table class='table table-bordered table-striped table-actions'>
                    <thead>
                      <tr>
                        <th>Matricule</th>
                        <th>Nom</th>
                        <th>Zone</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {personnels.map((item, index) => {
                        return (
                          <tr>
                            <td>{item.matricule}</td>
                            <td>{item.name}</td>
                            <td>{item.zone.name}</td>
                            <td>
                              <button
                                className='btn btn-light btn-rounded btn-sm'
                                onClick={() => deletePersonnel(index)}>
                                <i
                                  className='fa fa-trash-o'
                                  aria-hidden='true'></i>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Personnel;
