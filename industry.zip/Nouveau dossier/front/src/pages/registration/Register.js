/** @format */

import React, { useState, useRef } from "react";
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";
import CheckButton from "react-validation/build/button";
import { isEmail } from "validator";
import AuthService from "../../services/auth.service";

import "./register.css";

const required = (value) => {
  if (!value) {
    return <div className='text-danger'>This field is required! </div>;
  }
};
const validEmail = (value) => {
  if (!isEmail(value)) {
    return <div className='text-danger'>This is not a valid email. </div>;
  }
};

const vpassword = (value) => {
  if (value.length < 6 || value.length > 40) {
    return (
      <div className='text-danger'>
        The password must be between 6 and 40 characters.
      </div>
    );
  }
};
const Register = (props) => {
  const form = useRef();
  const checkBtn = useRef();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  const [successful, setSuccessful] = useState(false);
  const [message, setMessage] = useState("");

  const onChangeEmail = (e) => {
    const email = e.target.value;
    setEmail(email);
  };
  

  const onChangePassword = (e) => {
    const password = e.target.value;
    setPassword(password);
  };
  const onChangeConfirm = (e) => {
    const confirm = e.target.value;
    setConfirm(confirm);
  };
  const UserRegistration = (e) => {
    e.preventDefault();
    setMessage("");
    setSuccessful(false);
    form.current.validateAll();
    console.log(confirm, password);
    if (checkBtn.current.context._errors.length === 0) {
      AuthService.register(email, password, "user").then(
        (response) => {
          setMessage(response.data.message);
          setSuccessful(true);
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setMessage(resMessage);
          setSuccessful(false);
        }
      );
    } else {
      console.log("pass doesnt match!!");
    }
  };

  const AdminRegistration = (e) => {
    e.preventDefault();
    setMessage("");
    setSuccessful(false);
    form.current.validateAll();
    console.log(confirm, password);
    if (checkBtn.current.context._errors.length === 0) {
      AuthService.register(email, password, "admin").then(
        (response) => {
          setMessage(response.data.message);
          setSuccessful(true);
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setMessage(resMessage);
          setSuccessful(false);
        }
      )
    } else {
      console.log("pass doesnt match!!");
    }
  };
  return (
    <div className='register_container'>
      <div className='row'>
        <div className='title col-lg-12'>
          <h5>Accessible subscribers </h5>
          <p> global administrator</p>
        </div>
      </div>
      <div className='row'>
        <div className='user_register col-md-6'>
          <Form onSubmit={UserRegistration} ref={form}>
            <div>
              <div className='form-group'>
                <h5>Add new user</h5>
                <label htmlFor='email'>User e-mail</label>
                <Input
                  placeholder='User e-mail'
                  type='text'
                  className='form-control'
                  name='email'
                  value={email}
                  onChange={onChangeEmail}
                  validations={[required, validEmail]}
                />
              </div>
              <div className='form-group'>
                <label htmlFor='password'>Password:</label>
                <Input
                  placeholder='User password'
                  type='password'
                  className='form-control'
                  name='password'
                  value={password}
                  onChange={onChangePassword}
                  validations={[required, vpassword]}
                />
              </div>
              <div className='form-group'>
                <label className='password' htmlFor='password'>
                  Confirm Password:
                </label>
                <Input
                  onChange={onChangeConfirm}
                  value={confirm}
                  className='form-control'
                  type='password'
                  name='confirm password'
                  validations={[required, vpassword]}
                />
              </div>

              <div className='form-group'>
                <button className='btn_register'>User SignUp</button>
              </div>
            </div>

            {message && (
              <div className='form-group'>
                <div
                  className={
                    successful ? "alert alert-success" : "alert alert-danger"
                  }
                  role='alert'>
                  {message}
                </div>
              </div>
            )}
            <CheckButton style={{ display: "none" }} ref={checkBtn} />
          </Form>
        </div>
        <div className='admin_register col-md-6'>
          <Form onSubmit={AdminRegistration} ref={form}>
            <div>
              <div className='form-group'>
                <h5>Add new admin</h5>
                <label htmlFor='email'>E-mail:</label>
                <Input
                  placeholder='Admin e-mail'
                  type='text'
                  className='form-control'
                  name='email'
                  value={email}
                  onChange={onChangeEmail}
                  validations={[required, validEmail]}
                />
              </div>
              <div className='form-group'>
                <label htmlFor='password'>Password</label>
                <Input
                  placeholder='Admin password'
                  type='password'
                  className='form-control'
                  name='password'
                  value={password}
                  onChange={onChangePassword}
                  validations={[required, vpassword]}
                />
              </div>
              <div className='form-group'>
                <label className='password' htmlFor='password'>
                  Confirm Password:
                </label>
                <Input
                  value={confirm}
                  className='form-control'
                  type='password'
                  name='confirm password'
                  validations={[required, vpassword]}
                />
              </div>

              <div className='form-group'>
                <button className='btn_register'>Admin Sign Up </button>
              </div>
            </div>

            {message && (
              <div className='form-group'>
                <div
                  className={
                    successful ? "alert alert-success" : "alert alert-danger"
                  }
                  role='alert'>
                  {message}
                </div>
              </div>
            )}
            <CheckButton style={{ display: "none" }} ref={checkBtn} />
          </Form>
        </div>
      </div>
    </div>
  );
};
export default Register;
