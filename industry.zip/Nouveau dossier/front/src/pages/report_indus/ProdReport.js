/** @format */

import React from "react";
import "./report.css";
const ProdReport = () => {
  return (
    <div className='container report_container'>
      <div className='row uap_content report_row'>
        <div className='col-md uaplistTilte'>
          <h5>Production Report & Alea</h5>
        </div>
      </div>
      <div className='row uap_content'>
        <div className='col-md'>
          <h6>Could you choose</h6>
        </div>
      </div>
    </div>
  );
};

export default ProdReport;
